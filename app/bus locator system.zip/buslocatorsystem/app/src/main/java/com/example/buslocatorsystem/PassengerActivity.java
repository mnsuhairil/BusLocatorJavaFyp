package com.example.buslocatorsystem;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class PassengerActivity extends AppCompatActivity implements OnMapReadyCallback {

    // Firebase variables
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private FirebaseUser mUser;

    // Google Maps variables
    private GoogleMap mMap;
    private LocationManager mLocationManager;
    private LocationListener mLocationListener;
    private Marker mSelectedBusStopMarker;
    private Marker mCurrentLocationMarker;
    private Polyline mPolyline;
    private LatLng mCurrentLatLng;
    private LatLng mSelectedBusStopLatLng;

    // Other variables
    private String mSelectedBusId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger);

        // Initialize Firebase Auth and Database
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mUser = mAuth.getCurrentUser();

        // Initialize Google Maps
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Code for passenger activity
        // ...

        // Example of selecting a bus
        mSelectedBusId = "bus123";
        // Example of requesting/waiting for the bus
        requestBus();

        // Example of canceling the request/wait
        cancelRequest();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Enable user's current location
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        // Initialize location manager and listener
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        mLocationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                mCurrentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                updateCurrentLocationMarker();
                // Calculate and display estimated time of arrival
                calculateETA();
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {}

            @Override
            public void onProviderDisabled(String provider) {}
        };

        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    0, 0, mLocationListener);
        }

        // Add onMapClickListener for selecting bus stops
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                mSelectedBusStopLatLng = latLng;
                updateSelectedBusStopMarker();
                // Calculate and display estimated time of arrival
                calculateETA();
            }
        });
    }

    private void updateCurrentLocationMarker() {
        if (mMap != null && mCurrentLatLng != null) {
            if (mCurrentLocationMarker != null)
                mCurrentLocationMarker.remove();

            MarkerOptions markerOptions = new MarkerOptions()
                    .position(mCurrentLatLng)
                    .title("Current Location");

            mCurrentLocationMarker = mMap.addMarker(markerOptions);
        }
    }

    private void updateSelectedBusStopMarker() {
        if (mMap != null && mSelectedBusStopLatLng != null) {
            if (mSelectedBusStopMarker != null)
                mSelectedBusStopMarker.remove();

            MarkerOptions markerOptions = new MarkerOptions()
                    .position(mSelectedBusStopLatLng)
                    .title("Selected Bus Stop");

            mSelectedBusStopMarker = mMap.addMarker(markerOptions);

            // Draw polyline between current location and selected bus stop
            drawPolyline();
        }
    }

    private void drawPolyline() {
        if (mMap != null && mCurrentLatLng != null && mSelectedBusStopLatLng != null) {
            if (mPolyline != null)
                mPolyline.remove();

            PolylineOptions polylineOptions = new PolylineOptions()
                    .add(mCurrentLatLng)
                    .add(mSelectedBusStopLatLng)
                    .color(Color.BLUE)
                    .width(5);

            mPolyline = mMap.addPolyline(polylineOptions);
        }
    }

    private void calculateETA() {
        if (mCurrentLatLng != null && mSelectedBusStopLatLng != null) {
            // Implement algorithm to calculate estimated time of arrival (ETA)
            // ...
        }
    }

    private void requestBus() {
        if (mUser != null) {
            // Example code for requesting/waiting for the bus
            // ...

            // Notify the driver that a passenger is waiting
            notifyDriver();
        }
    }

    private void cancelRequest() {
        if (mUser != null) {
            // Example code for canceling the request/wait
            // ...

            // Notify the driver that the request has been canceled
            notifyDriver();
        }
    }

    private void notifyDriver() {
        // Example code for notifying the driver
        // ...
    }

    // Code for other passenger-related functionality
    // ...
}
